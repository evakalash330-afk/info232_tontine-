import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, r2_score
import os

st.set_page_config(page_title="TontiPredict", page_icon="💰", layout="wide")
st.title("💰 TontiPredict")
st.markdown("### Analyse intelligente des tontines africaines")

DATA_FILE = "tontine_data.csv"

if not os.path.exists(DATA_FILE):
    df_init = pd.DataFrame(columns=[
        "nom", "age", "profession", "revenu_mensuel", "montant_cotise",
        "nb_retards", "duree_adhesion", "montant_emprunte", "remboursement_temps"
    ])
    df_init.to_csv(DATA_FILE, index=False)

st.header("📝 Ajouter un membre")

with st.form("formulaire"):
    col1, col2 = st.columns(2)

    with col1:
        nom = st.text_input("Nom")
        age = st.slider("Âge", 18, 80, 30)
        profession = st.selectbox("Profession", ["Agriculteur", "Commerçant", "Fonctionnaire", "Étudiant", "Autre"])
        revenu = st.number_input("Revenu mensuel", 0, 10000000, 100000)

    with col2:
        cotisation = st.number_input("Montant cotisé", 0, 1000000, 25000)
        retards = st.slider("Nombre de retards", 0, 12, 0)
        duree = st.slider("Durée adhésion (mois)", 0, 60, 12)
        emprunt = st.number_input("Montant emprunté", 0, 10000000, 0)
        remboursement = st.selectbox("Remboursement", ["Oui", "Non", "Partiellement"])

    submit = st.form_submit_button("Enregistrer")

if submit and nom:
    new_data = pd.DataFrame([{
        "nom": nom,
        "age": age,
        "profession": profession,
        "revenu_mensuel": revenu,
        "montant_cotise": cotisation,
        "nb_retards": retards,
        "duree_adhesion": duree,
        "montant_emprunte": emprunt,
        "remboursement_temps": remboursement
    }])

    df = pd.read_csv(DATA_FILE)
    df = pd.concat([df, new_data], ignore_index=True)
    df.to_csv(DATA_FILE, index=False)

    st.success("✅ Membre ajouté !")

st.header("📊 Données")
df = pd.read_csv(DATA_FILE)

if len(df) > 0:
    st.dataframe(df)
    fig = px.bar(df, x="nom", y="montant_cotise", title="Cotisations")
    st.plotly_chart(fig)
else:
    st.info("Aucune donnée")

if len(df) >= 5:
    df_ml = df.copy()
    df_ml["remboursement_temps"] = df_ml["remboursement_temps"].map({
        "Oui": 1, "Non": 0, "Partiellement": 0.5
    })

    df_ml = pd.get_dummies(df_ml, columns=["profession"], drop_first=True)
    df_ml = df_ml.drop(columns=["nom"])
    df_ml = df_ml.fillna(df_ml.median())

    st.header("📈 Régression simple")
    X = df_ml[["revenu_mensuel"]]
    y = df_ml["montant_cotise"]
    model = LinearRegression()
    model.fit(X, y)

    st.write("R²:", r2_score(y, model.predict(X)))

    st.header("🤖 Classification retards")
    Xc = df_ml.drop(columns=["montant_cotise"])
    yc = (df_ml["nb_retards"] > 1).astype(int)

    X_train, X_test, y_train, y_test = train_test_split(Xc, yc, test_size=0.3, random_state=42)

    clf = RandomForestClassifier()
    clf.fit(X_train, y_train)

    st.write("Accuracy:", accuracy_score(y_test, clf.predict(X_test)))

    st.header("🔍 Clustering")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_ml)

    kmeans = KMeans(n_clusters=3, n_init=10)
    clusters = kmeans.fit_predict(X_scaled)

    df["Segment"] = clusters
    st.dataframe(df)
